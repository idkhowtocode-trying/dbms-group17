package model;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
public class SQLModel {
    /**
     * push the class instance field data to the database
     * may apply the insert or update sql statement
     * @return the instance after push
     * @throws SQLException
     */
    //public SQLModel pushToDatabase () throws SQLException;
}
