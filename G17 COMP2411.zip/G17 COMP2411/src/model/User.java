package model;

import java.sql.SQLException;
public class User implements SQLModel {
    private String userID;
    private String password;

    private String home_address;
    private String payment_method;
    //shopping cart connected to user

    public User(String userID){
        this.userID = userID;
    }
    public User(String userID, )
}
